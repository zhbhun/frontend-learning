import './app';

document.body.innerHTML = 'Side Effects';
