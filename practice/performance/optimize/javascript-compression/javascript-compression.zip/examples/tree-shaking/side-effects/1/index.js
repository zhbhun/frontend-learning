import { cube } from './math.js';

document.body.innerHTML = cube(3);
