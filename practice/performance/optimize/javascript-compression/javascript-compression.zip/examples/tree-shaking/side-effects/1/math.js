export function square(x) {
  return x * x;
}

square.toString();

export function cube(x) {
  return x * x * x;
}
