class Button {
  constructor() {
    this.name = 'Button';
  }
}

console.log(Button);

export default Button;
