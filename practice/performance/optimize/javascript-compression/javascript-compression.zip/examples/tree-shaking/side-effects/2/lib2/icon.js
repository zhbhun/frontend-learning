class Icon {
  constructor() {
    this.name = 'Icon';
  }
}

console.log(Icon);

export default Icon;
