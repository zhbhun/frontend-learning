import { Button } from 'antd';

export { Button };
