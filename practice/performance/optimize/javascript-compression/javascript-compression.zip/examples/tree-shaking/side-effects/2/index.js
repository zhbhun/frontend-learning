import { icon } from './lib1';
import { button } from './lib2';

document.body.innerHTML = icon + button;
