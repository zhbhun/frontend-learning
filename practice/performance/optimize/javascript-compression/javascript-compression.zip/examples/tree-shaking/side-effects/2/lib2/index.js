export { default as icon } from './icon';

export const button = 'button';
