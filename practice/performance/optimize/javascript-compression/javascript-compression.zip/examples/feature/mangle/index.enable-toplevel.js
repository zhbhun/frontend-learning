var a;

function n(a, n) {
    var r = a + n;
}