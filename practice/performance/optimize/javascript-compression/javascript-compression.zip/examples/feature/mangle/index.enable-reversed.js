var globalVar;

function funcName(firstLongName, a) {
    var n = firstLongName + a;
}