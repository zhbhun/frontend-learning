var globalVar;

function funcName(a, n) {
    var r = a + n;
}