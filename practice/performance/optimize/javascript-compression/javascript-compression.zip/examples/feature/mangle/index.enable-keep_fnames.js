var a;

function funcName(a, n) {
    var c = a + n;
}