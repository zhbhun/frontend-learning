var globalVar;

function funcName(firstLongName, anotherLongName) {
    var myVariable = firstLongName + anotherLongName;
}