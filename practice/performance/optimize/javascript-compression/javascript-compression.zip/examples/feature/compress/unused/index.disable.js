!function() {
    function cube(value) {
        return value * value * value;
    }
    console.log(cube(3));
}();