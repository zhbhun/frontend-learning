function rereturn(x) {
  return x;
}
rereturn(window);

function square ( x ) {
  return x.innerHeight * x.innerHeight;
}
square(window);

// function cube ( x ) {
//   return x.innerWidth * x.innerWidth * x.innerWidth;
// }
// /*@__PURE__*/
// cube(window)
