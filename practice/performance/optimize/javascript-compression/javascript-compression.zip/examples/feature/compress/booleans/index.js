var d = !!a ? b : c;
