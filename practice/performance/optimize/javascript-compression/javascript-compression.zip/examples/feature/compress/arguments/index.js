function testArguments(param){
  console.log(arguments[0]);
}
