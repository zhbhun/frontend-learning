function f() {
    return a(), b(), void (x = 10);
    x && y();
}