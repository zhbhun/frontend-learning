function f() {
  a();
  b();
  x = 10;
  return;
  if (x) {
      y();
  }
}
