function f() {
    a(), b(), x = 10;
}