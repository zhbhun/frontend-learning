function testArguments(param) {
    console.log(param);
}