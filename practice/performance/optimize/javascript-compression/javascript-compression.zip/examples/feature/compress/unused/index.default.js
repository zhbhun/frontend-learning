!function() {
    var value;
    console.log((value = 3) * value * value);
}();